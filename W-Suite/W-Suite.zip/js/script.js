$(document).ready(function(){
    $('.plan span').click(function(){
       $('.plan span').removeClass('active');
        $(this).addClass('active');
    });
});